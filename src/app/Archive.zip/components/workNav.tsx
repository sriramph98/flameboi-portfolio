import Link from 'next/link';

export default function WorkNav() {

    return (
<div className="space-x-8">
      <Link href="/music" className="text-2xl inline-block subNavActive">Music</Link>
      <Link href="/mixing" className="text-2xl inline-block subNavInActive">Mixing & Mastering</Link>
      <Link href="/editing" className="text-2xl inline-block subNavInActive">Editing </Link>
    </div>
    )
  }
  