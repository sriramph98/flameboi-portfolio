import WorkNav from "@/app/components/workNav";

export default function Mixing() {

  return (
    <>
   
   <div className='space-y-4'><WorkNav/></div>
<div>mixing</div>
      

    </>
  );
}