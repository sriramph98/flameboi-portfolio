import WorkNav from "@/app/components/workNav";


export default function Editing() {

  return (
    <>
   
   <div className='space-y-4'><WorkNav/></div>
<div>editing</div>
      

    </>
  );
}