import RootLayout from '../layout';

export default function Market() {
  return (
<div className='space-y-8'>
<h1>market</h1>
</div>

  );
}
